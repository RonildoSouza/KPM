<?php
require_once(__DIR__ . '/vendor/autoload.php');
require_once(__DIR__ . '/src/constants.php');
require_once(__DIR__ . '/config.php');

use Doctrine\ORM\Tools\Setup;
use Doctrine\ORM\EntityManager;

/**
 * Init Doctrine EntityManager
 */
$entityPath = __DIR__ . "/src/models/entities";
$paths = array($entityPath);
$metaConfig = Setup::createAnnotationMetadataConfiguration($paths, DEV_MODE);
$entityManager = EntityManager::create($config['dbParams'], $metaConfig);

/**
 * Init Slim App
 */
$app = new \Slim\App(["settings" => $config]);

$app->options('/WebKPM/{routes:.+}', function ($request, $response, $args) {
    return $response;
});

$app->add(function ($req, $res, $next) {
    $response = $next($req, $res);
    return $response
            ->withHeader('Access-Control-Allow-Origin', 'http://byrns.esy.es')
            ->withHeader('Access-Control-Allow-Headers', 'X-Requested-With, Content-Type, Accept, Origin, Authorization')
            ->withHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, PATCH, OPTIONS');
});
